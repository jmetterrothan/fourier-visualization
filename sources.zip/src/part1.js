// @ts-nocheck
import P5 from 'p5';

import sketch1 from './sketches/sketch1';

new P5(sketch1, document.getElementById('sketch1'));
