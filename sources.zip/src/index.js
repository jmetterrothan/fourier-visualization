// @ts-nocheck

import 'babel-polyfill';

import './assets/sass/index.scss';

import './part1';
import './part2';
